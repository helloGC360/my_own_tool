/*
Name - GULABCHANDRA MISTRI
Roll. no. - 24CSE42
*/

//Q
#include <stdio.h>


//insersion short
void ins_short(int arr[], int *size) {
    for (int j = 1; j < *size; j++) {
        int c = arr[j]; //saving the initial value
        int i = j;
        while (i > 0 && arr[i - 1] > c) { 
            arr[i] = arr[i - 1]; 
            i--;
        }
        arr[i] = c; //inserting value at correct position
    }
}


//printing of arr
void print_arr(int arr[],int *size){
    for(int i=0;i<*size;i++){
        printf("%d  ,",arr[i]);
        }
    }


int main()
{ 

//getting size of array
    int n;
    printf("enter size of array : ");
    scanf("%d",&n);
    int arr[n];//initializing array
    printf("enter array element :- \n");
    //getting array element
    for(int i=0;i<n;i++){
       printf("element :  %d  :  ",i);
       scanf("%d",&arr[i]);
        }
   
    ins_short(arr,&n);
    print_arr(arr,&n);
    return 0;
 }


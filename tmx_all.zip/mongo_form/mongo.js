const mongoose = require('mongoose');

// MongoDB Connection URI
const uri = `mongodb+srv://helloGC:2320Mongo@social-media.rtecwqn.mongodb.net/?retryWrites=true&w=majority&appName=Social-media`;

mongoose.connect(uri)
  .then(() => {
    console.log("Connected to MongoDB using Mongoose!");
  })
  .catch((err) => {
    console.error("Error connecting to MongoDB:", err.message);
  });



const stu = new mongoose.Schema({
    name: { type: String, required: true },
    clas: { type: String, required: true },
    roll: { type: String, required: true },
    mob: { type: String, default: true },
    email: {type: String,required: true},
    pass: {type:String,required:true}
});

// Create the Student Model
const student = mongoose.model('student',stu);

// Export the Student Model
module.exports = student;

/*
name - GULABCHANDRA MISTRI
roll. no. - 24CSE42
*/

//Q4.Implement a structure named Date with members for day, month, and year. Write a C program to take input for two dates and calculate the difference in days between them.


#include <stdio.h>


//declear data type struct name date
struct date
      {
	int day;
	int month;
	int year;
	};
	
	
//to check that given to date are correct or not
   int date_checker(int d,int m,int y){
       int k;
       if(!(y>=0 && month_to_day(m,&k,y) && (d>0 && d<=k))){
              return 1;
              }
       }
   
    
//to check leap year, used to find total day in feb month
    int leap_year(int year){
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }
    


//getting total no. of day in each month 
//return statement is used as flag, that indicating given month are correct or not
  int month_to_day(int input_month,int *output_day,int year)
  {
     switch (input_month){
     case 1:*output_day=31;
            break;
     case 2:if(leap_year(year)){
            *output_day=29;
              }else{
            *output_day=28;
            }
            break;
     case 3:*output_day=31;
            break;
     case 4:*output_day=30;
            break;
     case 5:*output_day=31;
            break;
     case 6:*output_day=30;
            break;
     case 7:*output_day=31;
            break;
     case 8:*output_day=31;
            break;
     case 9:*output_day=30;
            break;
     case 10:*output_day=31;
            break;
     case 11:*output_day=30;
            break;
     case 12:*output_day=31;
            break;
     default:*output_day=0;
             return 0;
   }
   return 1;
 }



//used to count total no. of day b/w given date
    int count_diff(int d1,int m1,int y1,int d2,int m2,int y2)
    {
       int output_day,count=0;
       while(y1>=y2)
       {
	    if(y1==y2 && m1==m2 && d1==d2){
           break;
           };
           d1--;
           if(d1==0 && m1>0){
           m1--;
           if(m1==0 && y1>0){
              m1=12;
              y1--;
            }
            month_to_day(m1,&output_day,y1);
            d1=output_day; 
          }
         printf("day=%d ,mon=%d ,y1=%d ,\n",d1,m1,y1);
         count++;
         }
        return count;
    }





	int main()
	{
//getting date by user
	struct date  now , old;
	printf("enter the old date :-\n");
	printf(" old date day : ");
	scanf("%d",&old.day);
	printf(" old date month : ");
	scanf("%d",&old.month);
	printf(" old date year : ");
	scanf("%d",&old.year);
	
	printf("\nenter the latest date :-\n");
	printf(" latest date day : ");
	scanf("%d",&now.day);
	printf(" latest date month : ");
	scanf("%d",&now.month);
	printf(" latest  date year : ");
	scanf("%d",&now.year);
	
	
          
//storing date into friendly variable for easy         
    int d1=old.day,m1=old.month,y1=old.year;
    int d2=now.day,m2=now.month,y2=now.year;
 

/*    
  printf("\ndate 1 :  %d/%d/%d\n",d1,m1,y1);
  printf("date 2 :  %d/%d/%d\n",d2,m2,y2);
*/


//seperating latest or oldest date
    if(y2>y1){
       int temp=y1;
       y1=y2;
       y2=temp;
       temp=m1;
       m1=m2;
       m2=temp; 
       temp=d1;
       d1=d2;
       d2=temp;
    }else if(y1>y2){}else{
       if(m2>m1){
       int temp=m1;
       m1=m2;
       m2=temp;
       temp=d1;
       d1=d2;
       d2=temp;
      }else{
       if(d2>d1){
              int temp=d1;
              d1=d2;
              d2=temp;
          }
       }
     }
 
  


//printing date
  printf("\nnew date :  %d/%d/%d\n",d1,m1,y1);
  printf("old date :  %d/%d/%d\n",d2,m2,y2);



//checking given date is correct or not
     int f1 = date_checker(d1,m1,y1);
     int f2 =date_checker(d2,m2,y2);
     
     
     
//reacting according to the flag
     if(f1==1 || f2==1){
       printf("invalid date");
       return 0;
     }




//getting the total no. of day in day variable
     int day=count_diff(d1,m1,y1,d2,m2,y2);  
//printing of day
     printf(" day =  %d ",day);



  
	return 0;
	}
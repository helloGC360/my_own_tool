/*
Name - Gulabchandra Mistri
roll.No.-24CSE42
Branch-CSE
*/

//    var URL = `https://results.beup.ac.in/ResultsBTech8thSem2024Pub.aspx?Sem=VIII&RegNo=`; //8th 2020 batch
//    var URL =`https://results.beup.ac.in/ResultsBTech8thSem2025Pub.aspx?Sem=VIII&RegNo=`;    //8th 2021 batch
//var URL="https://results.beup.ac.in/ResultsBTech4thSem2024_B2022Pub.aspx?Sem=IV&RegNo=";

const rn_year=23; //for registration number



const fetch = require("node-fetch"); //to fetch url
const cheerio = require("cheerio"); //to make html(of response) accessible as dom
const fs = require("fs"); //to write File



let clg_topper=[]; //to store all clg topper
let branch_topper=[]; //to store all branch_topper
var count=1; //to count total no. of student
var topper=[]; //to store temperory  topper
var min=0;  //used in to find topper




//time dependent file name
const file= `GC_${new Date().toISOString().replace(/[-:T.]/g, '').slice(0, 15)}_result.csv`;

//hadder of CSV file
const hadder="S.N.,Rn.no.,Name,sem1,sem2,sem3,sem4,sem5,sem6,sem7,sem8,ovr.all,branch,college";

//writing hadder in the file 
     fs.appendFile(`${file}`,`${hadder}\n`,(err)=>{
     if(err){console.log(err);}
     else{console.log(`${file} creation done!!`)}
     });


//main function
async function get_result(rollno) {
//       let URL=`https://results.beup.ac.in/ResultsBTech3rdSem2023_B2022Pub.aspx?Sem=III&RegNo=${rollno}`
//     let URL=`https://results.beup.ac.in/ResultsBTech4thSem2024_B2022Pub.aspx?Sem=IV&RegNo=${rollno}`;
//    let URL=`https://results.beup.ac.in/ResultsBTech1stSem2022_B2022Pub.aspx?Sem=I&RegNo=${rollno}`  
//let URL=`https://results.beup.ac.in/ResultsBTech2ndSem2023_B2022Pub.aspx?Sem=II&RegNo=${rollno}`
let URL=`https://results.beup.ac.in/ResultsBTech2ndSem2024_B2023Pub.aspx?Sem=II&RegNo=${rollno}`


try {
    var response = await fetch(URL);
    var html = await response.text();
    var $ =await cheerio.load(html);

    let studentName =await  $("#ContentPlaceHolder1_DataList1_StudentNameLabel_0").text().trim();
    let tcgpa =await  $('#ContentPlaceHolder1_GridView3 tr:nth-child(2) td:nth-child(9)').text().trim();;
    let cgpa1 =await  $('#ContentPlaceHolder1_GridView3 tr:nth-child(2) td:nth-child(1)').text().trim();;
    let cgpa2 =await  $('#ContentPlaceHolder1_GridView3 tr:nth-child(2) td:nth-child(2)').text().trim();;
    let cgpa3 =await  $('#ContentPlaceHolder1_GridView3 tr:nth-child(2) td:nth-child(3)').text().trim();;
    let cgpa4 =await  $('#ContentPlaceHolder1_GridView3 tr:nth-child(2) td:nth-child(4)').text().trim();;
    let cgpa5 =await  $('#ContentPlaceHolder1_GridView3 tr:nth-child(2) td:nth-child(5)').text().trim();;
    let cgpa6 =await  $('#ContentPlaceHolder1_GridView3 tr:nth-child(2) td:nth-child(6)').text().trim();;
    let cgpa7 =await  $('#ContentPlaceHolder1_GridView3 tr:nth-child(2) td:nth-child(7)').text().trim();;
    let cgpa8 =await  $('#ContentPlaceHolder1_GridView3 tr:nth-child(2) td:nth-child(8)').text().trim();;
    let branch =await  $("#ContentPlaceHolder1_DataList1_CourseLabel_0").text().trim();
    let college= await $("#ContentPlaceHolder1_DataList1_CollegeNameLabel_0").text().trim().replace(/[-:T.,]/g, '');
   //writing csv file line
    let csv_line = `${count}.,${rollno},${studentName},${cgpa1},${cgpa2},${cgpa3},${cgpa4},${cgpa5},${cgpa6},${cgpa7},${cgpa8},${tcgpa},${branch},${college}`;
   //selecting branch topper
    if(min<tcgpa){
     min=tcgpa;
     topper=[`${count}`,`${rollno}`,`${studentName}`,`${cgpa1}`,`${cgpa2}`,`${cgpa3}`,`${cgpa4}`,`${cgpa5}`,`${cgpa6}`,`${cgpa7}`,`${cgpa8}`,`${tcgpa}`,`${branch}`,`${college}`];;
    }

    //writing all result in file
    fs.appendFile(`${file}`,`${csv_line}\n`,(err)=>{
     if(err)console.log(err);
    });
    count++;
    console.log(csv_line);

  }catch (error) {
   console.error("sorry GC i couldn't", error);
  }


}







//finding college topper
   function findClgTopper(){
       let max=0;
       for(let i=0;i<branch_topper.length;i++){
          if(max<branch_topper[i][11]){
            topper=branch_topper[i];
            max=branch_topper[i][11];
           }
           }
           clg_topper.push(topper);
    }


//writing all toppers in topper list of CSV file
  function topper_list(){
           fs.appendFile(`${file}`,`\n\ncollege topper:--\n`,(err)=>{
           console.log("clg topper listening...");
           });
      for(let i=0; i<clg_topper.length;i++){
           fs.appendFile(`${file}`,`${clg_topper[i]}\n`,(err)=>{
           console.log("clg topper done!!");
           });
       }
           fs.appendFile(`${file}`,`\n\nbranch topper:--\n`,(err)=>{
           console.log("branch topper listening...");
           });
      for(let i=0;i<branch_topper.length;i++){
           fs.appendFile(`${file}`,`${branch_topper[i]}\n`,(err)=>{
           console.log("branch topper done!!");
           });
       }
   }




//monitor of main function to get appreciate result
  let roll;
  const bcode = [103];
  const clg_code = [135];
  (async ()=>{
      for(let clg=0;clg<clg_code.length;clg++){
      for(let j=0;j<bcode.length;j++){
      for(let i=1;i<=65;i++){
         if(i<10){
            roll=`${rn_year}${bcode[j]}${clg_code[clg]}00` + `${i}`;
         }else{
            roll=`${rn_year}${bcode[j]}${clg_code[clg]}0` + `${i}`;
         }
       await get_result(roll);
       }
       branch_topper.push(topper);
       min=0;
       }
       findClgTopper();
       }
    topper_list();
  })();


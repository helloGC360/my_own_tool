/*
NAME - GULABCHANDRA MISTRI,
ROLL. NO. - 24CSE42
*/

//Q1.Design a structure named Book to store details such as title, author, and price. Develop a C program that accepts input for three books, determines the most expensive and least expensive books, and displays their details.


#include <stdio.h>


//declearation of structure datatype
struct book
	{
		char title[30];
		char author[30];
		float price;
	};



int main()
{
   int n=3;   //number of book
   struct book b[n];   //initializing the indivisiual book
   


 //getting book detail using loop
   for (int i=0;i<n;i++){
   	printf("enter title of book %d : ",i);
   	scanf("%s",&b[i].title);
   	printf("enter author name of book %d : ",i);
   	scanf("%s",&b[i].author);
   	printf("enter price of book %d : ",i);
   	scanf("%f",&b[i].price);
   	printf("\n\n");
   	}
   	
   	

//printing all book we have
/*
   for (int i=0;i<n;i++){
   	printf("book %d price : %f \n",i,b[i].price);
   	printf("book %d title name : %s\n",i,b[i].title);
   	printf("book %d author name : %s\n",i,b[i].author);
   	printf("\n");
   	}
*/

//getting index of most expensive and least expensive book using like selection short
	  int min,max,mxi,mni;
      max=b[0].price;
      mxi=0;
      max=b[0].price;
      mni=0;
      for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
        if(max<b[j].price){
            max=b[j].price;
            mxi=j;
         }
         if(min>b[j].price){
            min=b[j].price;
            mni=j;
         }
        }
      }


	if(min==max){
//if all book have same price			
	printf("all book have same price  \n");
	}else{
//printing of  most expensive and least expensive book
    printf("least expensive :- \n");
    printf("book %d price : %f \n",mni,b[mni].price);
    printf("book %d title name : %s\n",mni,b[mni].title);
    printf("book %d author name : %s\n",mni,b[mni].author);
    printf("\n");
    printf("most expensive :- \n");
    printf("book %d price : %f \n",mxi,b[mxi].price);
    printf("book %d title name : %s\n",mxi,b[mxi].title);
    printf("book %d author name : %s\n",mxi,b[mxi].author);
    printf("\n");
    }
		

	return 0;
}
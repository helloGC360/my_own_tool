/*
Name - GULABCHANDRA MISTRI
Roll. no. - 24CSE42
*/

//Q1. Write a C program to implement Linear search

#include <stdio.h>

int main()
{ 
//getting size of array
    int n;
    printf("enter size of array : ");
    scanf("%d",&n);
    int arr[n];//initializing array
    printf("enter array element :- \n");
    //getting array element
    for(int i=0;i<n;i++){
       printf("element :  %d  :  ",i);
       scanf("%d",&arr[i]);
        }
   
   //getting target element
    int target;
    printf("enter your target Element  : ");
    scanf("%d",&target);
    
    
    //to store index of target and flag to check target exist or not
    int index_of_target,flag=0;
    
    //linear search 
    for(int i=0;i<n;i++){
        if(arr[i]==target){
            index_of_target=i;
            flag=1;
            break;
            }
    }
    
    
    //output according to flag 
    if(flag==1){
        printf("target found on index of %d",index_of_target);
        }else{
           printf("target not found");
            }
    
    return 0;
 }


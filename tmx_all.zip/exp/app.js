const express = require("express");
const app = express();
const path = require("path");

// Corrected spelling: 'extended' instead of 'extented'
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname,"public")));
// Updated route
app.get("/", (req, res) => {
  res.sendFile("index.html"); // send HTML file directly
});

app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});

/*
Name - GULABCHANDRA MISTRI
Roll. no. - 24CSE42
*/

//Q2. Write a program in C to swap elements using call by reference.


#include <stdio.h>

void swap(int *num1,int *num2){
    int temp=*num1;
    *num1=*num2;
    *num2=temp;
    }
    
int main()
{ 
int num1,num2;

    printf("enter num1: ");
    scanf("%d",&num1);
    
    printf("enter num2: ");
    scanf("%d",&num2);
    
    swap(&num1,&num2);
    
    printf(" num1 : %d \n num2 : %d ",num1,num2);
    return 0;
 }


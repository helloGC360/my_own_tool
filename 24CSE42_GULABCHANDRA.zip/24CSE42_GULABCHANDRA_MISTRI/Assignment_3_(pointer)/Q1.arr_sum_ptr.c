/*
Name - GULABCHANDRA MISTRI
Roll. no. - 24CSE42
*/

//Q1. Write a program in C to compute the sum of all elements in an array using pointers.



#include <stdio.h>

int arr_sum(arr,int size,int *sum){
    *sum=0;
    for(int i=0;i<size,i++){
        *sum=*sum+arr[i];
        }
    }
int main()
{ 
    int sum;
    int size;
    
    return 0;
 }


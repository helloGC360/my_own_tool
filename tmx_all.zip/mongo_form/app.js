const express = require("express");
const app = express();

const path = require("path");
const std = require("./mongo");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const cookieParser = require("cookie-parser");






app.set("view engine","ejs");
app.use(express.json());
app.use(express.urlencoded({extended : true}));
app.use(express.static(path.join(__dirname + "public")));
app.use(cookieParser());



app.get("/",(req,res)=>{
res.render("form");
});



app.post("/reg",async (req,res)=>{
data=req.body;
let user=await std.findOne({email:data.email});
if(user){
res.redirect("/login");
}else{
let token=jwt.sign({email:data.email},"gc_secret");
res.cookie("gc_cookie",token);
bcrypt.genSalt(10,(err,salt)=>{
if(err){
  console.log(err);
  return;
}else{
bcrypt.hash(data.pass,salt,async (err,hash)=>{
if(err){
console.log(err);
return;
}else{
await std.insertOne({
name:data.name,
clas:data.clas,
roll:data.roll,
mob:data.mob,
email:data.email,
pass:data.pass
});
res.redirect("/prof")
};
});
};
});
}
});;



app.get("/prof",islogin,async (req,res)=>{
let user =await  std.findOne({email:req.user.email});
if(user){
res.render("prof",{user});
}else{
res.redirect("/");
}
});



async function islogin(req,res,next){
let btok=req.cookies.gc_cookie;
if(!btok){
res.redirect("/login");
return;
}else{
let tokenr =await  jwt.verify(btok,"gc_secret");
req.user=tokenr;
next();
}
}




app.get("/logout",(req,res)=>{
res.cookie("gc_cookie","");
res.redirect("/login");
})



app.get("/login",(req,res)=>{
res.render("login");
});


app.post("/loggedin",async (req,res)=>{
let data=await req.body;
let user =await std.findOne({email:data.email});
if(!user){
res.redirect("/");
}else{
let result=await bcrypt.compare(data.pass,user.pass);
if(result){
 let token=await jwt.sign({email:data.email},"gc_secret");
 res.cookie("gc_cookie",token);
 res.redirect("/prof");
}else{
res.redirect("/login");
}
}
});



app.listen(3000,(err)=>{
if(err)
console.log(err);
else
console.log("server running on 3000");
})


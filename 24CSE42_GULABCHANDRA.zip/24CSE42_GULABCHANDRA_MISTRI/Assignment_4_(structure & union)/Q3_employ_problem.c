/*
NAME - GULABCHANDRA MISTRI,
ROLL. NO. - 24CSE42
*/

//Q3. Define a structure named Employee to store details like employee ID, name, and salary. Implement a C program that collects data for three employees, identifies the one with the highest salary, and prints their information.



#include <stdio.h>

//declearation of structure datatype
struct employee
	{
		char id[30];
		char name[30];
		int salary;
	};



int main()
{
   int n=3;   //number of employee
   struct employee emp[n];   //initializing the indivisiual employee as array
   


 //getting book detail using loop
   for (int i=0;i<n;i++){
   	printf("employee  %d ID : ",i+1);
   	scanf("%s",&emp[i].id);
   	printf("employ %d  NAME : ",i+1);
   	scanf("%s",&emp[i].name);
   	printf("employee %d SALARY : ",i+1);
   	scanf("%d",&emp[i].salary);
   	printf("\n");
   	}
   	
   	

//printing all book we have
printf("\n \n list of all employee :- \n");
   for (int i=0;i<n;i++){
   	printf("employee  %d ID : %s\n",i+1,emp[i].id);
   	printf("employee  %d NAME : %s\n",i+1,emp[i].name);
   	printf("employee  %d SALARY : %d\n",i+1,emp[i].salary);
   	printf("\n");
   	}


//getting index of most expensive and least expensive book using like selection short
	   int max;
	for(int i=0;i<n;i++){
		for(int j=1;j<n;j++){
     if(emp[i].salary>emp[j].salary)
     max=i;
		}
	}



//printing employee having high salary
    printf("employ %d have heighst salary :- \n",max+1);
    printf("employee  %d ID : %s\n",max+1,emp[max].id);
    printf("employee  %d NAME : %s\n",max+1,emp[max].name);
    printf("employee  %d SALARY : %d\n",max+1,emp[max].salary);
    printf("\n");
    
		

	return 0;
}
const manu=document.getElementById('manu');
const nav=document.getElementsByClassName('nav');
const ch=document.getElementsByClassName('ch');
var n=ch.length;
let k=1;
  function an(){
   
    if(k==1){
      manu.style=`width:200px;height:${n*35}px;transition:0.5s`;
      nav[0].style="background:green;transition:0.5s";
      for(let i=0;i<n;i++){
        ch[i].style="font-size:15px;transition:0.3s"
      }
      
      k=0;
    }else{
      manu.style='height:00px;width:10px;top:4vh;right:10vw;transition:0.5s';
      nav[0].style="background:black;transition:0.5s";
      for(let i=0;i<n;i++){
        ch[i].style="font-size:0px;transition:0.3s"
      }
      k=1;
    }
    }
    
    
    
    const butter=document.getElementsByClassName('bt');
    for(let i=0;i<butter.length;i++ ){
     butter[i].addEventListener("mouseenter",randpos);
     
    }
    
    let ty=0,x,y;
    let time;
    function randpos(){
    for(let i=0;i<butter.length;i++ ){
      
       x = Math.floor((Math.random()*1000)%(window.innerWidth));
       y = Math.floor((Math.random()*1000) %( window.innerHeight));
      
      time=(ty-y)/100;
      if(time<0){time=(-1)*time}
      if(time<=3){time=3}
     
     butter[i].style=`top:${y}px;left:${x}px;transition:${time}s ease;`;
    //  console.log(time,x,y);
      ty=y;
    }
    }
    randpos();
    
    
    
    const can=document.getElementById('can');
    const p1=document.getElementById('p1');
    const rect = can.getBoundingClientRect();
    const ctx=can.getContext("2d");
    can.width=p1.clientWidth;
    can.height=p1.clientHeight;
    const cwid=p1.clientWidth;
    const chgt=p1.clientHeight;
    console.log(cwid,chgt);
    const parti=[];
    let hue=1;
    /*ctx.fillStyle="red";
       ctx.beginPath();
       ctx.arc(30,30,10,0,Math.PI*2);
       ctx.fill();
       */
    
   class dust{
     constructor() {
       this.x=(Math.random()*280- 170)+170;
       this.y=(Math.random()*320- 170)+170;;
       this.size=Math.random()*15-0;
       this.speedX=Math.random()*2-0.5;
       this.speedY=Math.random()*2-0.5;
       this.color='hsl('+hue+',100%,50%)'
     }
     draw(){
     /*  ctx.fillStyle=this.color;
     ctx.beginPath();
     ctx.arc(this.x,this.y,this.size,0,Math.PI*2);
     ctx.fill();
      */
//draw heart by chatGPT
const topCurveHeight = this.size *0.3;
ctx.beginPath();
ctx.moveTo(this.x, this.y + topCurveHeight);
// Left side of heart
ctx.bezierCurveTo(
  this.x - this.size, this.y - topCurveHeight,
  // Control point 1
  this.x - this.size, this.y + this.size,
  // Control point 2
  this.x, this.y + this.size * 1.5
  // End point
);
// Right side of heart
ctx.bezierCurveTo(
  this.x + this.size, this.y + this.size, 
  // Control point 1
  this.x + this.size,this.y -topCurveHeight,   
  // Control point 2
  this.x, this.y + topCurveHeight
  // End point (back to top)
);
ctx.fillStyle =this.color;
ctx.fill();
     }
     
     update(){
       this.x += this.speedX;
       this.y += this.speedY;
       if(this.size>0.4) this.size -=0.03;
     }
   }
   
   
   
   
   function createParticle(){
     hue=Math.random() * 360;
     for(let i=0;i<100;i++){
       parti.push(new dust());
     }
   }
 createParticle();
 
   
   
   
   
   
   function start(){
   for(let i=0;i<parti.length;i++){
     parti[i].draw();
     parti[i].update();
     if(parti[i].size<=0.5){
       parti.splice(i,1);
       i--;
     }
     if(parti.length<=50){
       createParticle();
     }
   }
  //   console.log(parti.length)
   }
   
   
   
   
   
   
   function animate() {  
   ctx.fillStyle="rgba(0,0,0,0.4)"
  ctx.fillRect(0,0,cwid,chgt)
  ;
//ctx.clearRect(0, 0,cwid+rect.left,chgt+rect.top);
 start();
 hue++;
  requestAnimationFrame(animate);
}
animate();






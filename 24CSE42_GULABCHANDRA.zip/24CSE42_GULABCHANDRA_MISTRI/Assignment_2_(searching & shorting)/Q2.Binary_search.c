/*
Name - GULABCHANDRA MISTRI
Roll. no. - 24CSE42
*/

//Q2.write a C program to implement Binary search


// ---> since binary search is applicable only for shorted array so we will short it first


#include <stdio.h>


//used in shorting to swap two no. 
void swap(int *a,int *b){
    int temp=*a;
    *a=*b;
    *b=temp;
    }
    
    //bubble short selection
void bb_short(int arr[],int size){
    int flag=0;
    for(int j=1;j<size-1;j++){
    for(int i=0;i<size-j;i++){
        if(arr[i]>arr[i+1]){
            swap(&arr[i],&arr[i+1]);
            flag=1;
            }
        }
        if(flag==0){
            break;
            }
    }
}

//to print arr element}
void print_arr(int arr[],int size){
    for(int i=0;i<size;i++){
        printf("%d   , ", arr[i] );
        }
    }




int main()
{
    //getting size of array
    int n;
    printf("enter size of array : ");
    scanf("%d",&n);
    int arr[n];//initializing array
    printf("enter array element :- \n");
    //getting array element
    for(int i=0;i<n;i++){
       printf("element :  %d  :  ",i);
       scanf("%d",&arr[i]);
        }
   
   
   bb_short(arr,n);
   printf("shorted arr is :-\n");
   print_arr(arr,n);
   printf("\n");
   //getting target element
    int target;
    printf("enter your target Element  : ");
    scanf("%d",&target);
    
    
    //to store index of target and flag to check target exist or not
    int index_of_target,flag=0,l=0,r=n;
   
    //
    while(l<=r){
       int mid=(l+r)/2;
        if(arr[mid]==target){
            index_of_target=mid;
            flag=1;
            break;
            }
        if(arr[mid]>target){
            r=mid-1;
            }else{
                l=mid+1;
                }
        }
    
    
    
    //output according to flag 
    if(flag==1){
        printf("target found on index of %d",index_of_target);
        }else{
           printf("target not found");
            }
    return 0;
 }


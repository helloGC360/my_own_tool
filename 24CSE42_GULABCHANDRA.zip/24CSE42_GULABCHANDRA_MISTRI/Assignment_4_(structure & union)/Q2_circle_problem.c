/*
NAME - GULABCHANDRA MISTRI,
ROLL. NO. - 24CSE42
*/


//Create a structure named Circle to represent a circle with a given radius. Write a C program to compute and display the area and perimeter of two circles.
#include <stdio.h>

const float pi=3.14; //constant pi


//declear circle datatype
struct circle{
float radius;
};



//area finder function
void area_finder(float area[],struct circle crcl[],int *size){
    for(int i=0;i<*size;i++){
        area[i]=pi*crcl[i].radius*crcl[i].radius;
}
}


//perimeter finder function
void perimeter_finder(float perimeter[],struct circle crcl[],int *size){
    for(int i=0;i<*size;i++){
        perimeter[i]=2*pi*crcl[i].radius;
}
}
 

int main()
{


int n=2; //number of circle
struct circle crcl[n];
float area[n];  //to store area of each circle
float perimeter[n]; //to store perimeter of circle


//getting input circle radius
for(int i=0;i<n;i++){
    printf("enter radius of circle %d : ",i+1);
    scanf("%f",&crcl[i].radius);
}

//calling both function to get result
area_finder(area,crcl,&n);
perimeter_finder(perimeter,crcl,&n);

//printing of result
for(int i=0;i<n;i++){
    printf("area of circle %d is %f ",i+1,area[i]);
    printf("\nperimeter of circle %d is %f \n\n",i+1,perimeter[i]);
}


    return 0;
}